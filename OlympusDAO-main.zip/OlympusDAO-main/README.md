# OlympusDAO

A readable version of OlympusDAO smart contracts with Hardhat.

You can find the original repository here, with **flatten** contracts => https://github.com/OlympusDAO/olympus-contracts

### Why "readable" ?

The smart contracts provided by the team are flatten, so not really easy to read, audit, fork...
